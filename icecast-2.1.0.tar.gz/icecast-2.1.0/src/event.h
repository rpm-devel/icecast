/* Icecast
 *
 * This program is distributed under the GNU General Public License, version 2.
 * A copy of this license is included with this source.
 *
 * Copyright 2000-2004, Jack Moffitt <jack@xiph.org, 
 *                      Michael Smith <msmith@xiph.org>,
 *                      oddsock <oddsock@xiph.org>,
 *                      Karl Heyes <karl@xiph.org>
 *                      and others (see AUTHORS for details).
 */

#ifndef __EVENT_H__
#define __EVENT_H__

#define EVENT_NO_EVENT 0
#define EVENT_CONFIG_READ 1

void event_config_read (void);

#endif  /* __EVENT_H__ */
